import { useEffect, useState } from 'react';
//import line from '../types'

export const useFetch = (url: string) => {
    const [response, setResponse] = useState<any>(null)
    const [loading, setLoading] = useState<boolean>(false)
    const [hasError, setHasError] = useState<boolean>(false)
    useEffect(() => {
        const myFetch = async () =>{
        setLoading(true);
        const res: any = await fetch(url)
            .catch(() => {
                setHasError(true)
                setLoading(false)
            });
        const ans: any  = await res.json();
        setLoading(false)
        setResponse(ans)
        }
        myFetch();

    }, [ url  ])
    return { response, loading, hasError }
}
