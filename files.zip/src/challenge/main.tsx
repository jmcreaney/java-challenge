import { useFetch } from "../hooks/useFetch"
import DisplayData from "./displayData";
import  dataDisplayType from "./types";

const url: string =  process.env.REACT_ASPP_API || "https://fakerapi.it/api/v1/images?_width=380";


export default function Main(){
    const { response: obj } = useFetch(url);
 
    while(obj ===  null || obj === null){
      return <>Loading from {url}...</>;
    }

    const total: number = obj.total;

    return (
        <div className="main-screen">
            <center>
                <h1>
                    API Read Data Challenge
                </h1>
            </center>
            <div>Number of Items:{total}</div>
            <div className="dataLoop">{
                obj.data.map((v: dataDisplayType) => (
                    <DisplayData output={v} />
                ))}
            </div>

        </div>
    )
}