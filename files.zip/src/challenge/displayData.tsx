import { useEffect, useState } from 'react';

export default function DisplayData({output}: any){
    const [response, setResponse] = useState<any>(null)
    const [loading, setLoading] = useState<boolean>(false)
    const [hasError, setHasError] = useState<boolean>(false)

    useEffect(() => {
        const myFetch = async () =>{
        setLoading(true);
        const res: any = await fetch(output.url)
            .catch(() => {
                setHasError(true)
                setLoading(false)
            });
        const pic: any  = await res.url;
        setLoading(false)
        setResponse(pic)
        }
        myFetch();

    }, [ output.url ])

    return (
        <div className="displayObject">
            <hr />
            <li>
                {output.title}           
            </li>
            <li>
               { output.description }
            </li>
            <img src={response} alt={output.url} /> 
        </div>

    )
    
}

