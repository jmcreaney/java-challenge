

export default interface dataDisplayType{
    title: string;
    description: string;
    url: string
}